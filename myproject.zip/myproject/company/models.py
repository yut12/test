from django.db import models
from accounts.models import CustomUser

class Company(models.Model):
    user = models.ForeignKey(CustomUser,verbose_name="ユーザー",on_delete=models.PROTECT)
    title = models.CharField(verbose_name='予定日(oooo年oo月oo日)',max_length=11)
    content = models.TextField(verbose_name='本文',blank=True,null=True)
    photo1 = models.ImageField(verbose_name='顔写真',blank=True,null=True)
    
    created_at = models.DateTimeField(verbose_name='申請日時',auto_now_add=True)
    updated_at = models.DateTimeField(verbose_name='更新日時',auto_now=True)

class Mate:
    verbose_name_plural = 'Company'

    def __str__(self):
        return self.title


# Create your models here.
