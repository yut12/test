from django.urls import path

from . import views

app_name = 'company'
urlpatterns = [
    path('',views.IndexView.as_view(),name="index"),
    path('inquiry/',views.InquiryView.as_view(),name="inquiry"),
    path('company-list/',views.CompanyListView.as_view(),name="company_list"),
    path('company-detail/<int:pk>/',views.CompanyDetailView.as_view(),name="company_detail"),
    path('company-create/',views.CompanyCreateView.as_view(), name="company_create"),
    path('company-update/<int:pk>/',views.CompanyUpdateView.as_view(),name="company_update"),
    path('company-delete/<int:pk>/',views.CompanyDeleteView.as_view(),name="company_delete"),
]