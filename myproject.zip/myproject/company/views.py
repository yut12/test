
import logging

from django.views import generic

from .forms import InquiryForm,CompanyCreateForm

from django.contrib import messages

from django.urls import reverse_lazy

from .models import Company

from django.contrib.auth.mixins import LoginRequiredMixin

logger = logging.getLogger(__name__)

class IndexView(generic.TemplateView):
    template_name = 'index.html'

class InquiryView(generic.FormView):
    template_name = 'inquiry.html'
    form_class = InquiryForm
    success_url = reverse_lazy('company:inquiry')

    def form_valid(self, form):
        form.send_email()
        messages.success(self.request, 'メッセージを送信しました。')
        logger.info('Inquiry sent by {}'.format(form.cleaned_data['name']))
        return super().form_valid(form)

class CompanyListView(LoginRequiredMixin,generic.ListView):
    model = Company
    template_name = 'company_list.html'

    def get_quryset(self):
        diaries = Company.objects.filter(user=self.request.user).order_by('-created_at')
        return diaries

class CompanyDetailView(LoginRequiredMixin,generic.DetailView):
    model = Company
    template_name = 'company_detail.html'

class CompanyCreateView(LoginRequiredMixin,generic.CreateView):
    model = Company #model.py
    template_name = 'company_create.html'#templete.py
    form_class = CompanyCreateForm #forms.py
    success_url = reverse_lazy('company:company_list')

    def form_valid(self,form):#
        diary = form.save(commit=False)
        diary.user = self.request.user
        diary.save()
        messages.success(self.request,'予定を記録しました')#
        return super().form_valid(form)
        def form_invalid(self,form):#
            messages.error(self.request,"予定の記録に失敗しました。")
            return super().form_invalid(form)

class CompanyUpdateView(LoginRequiredMixin,generic.UpdateView):
    model = Company
    template_name = "company_update.html"
    form_class = CompanyCreateForm

    def get_success_url(self):
        return reverse_lazy('company:company_detail',kwargs={'pk':self.kwargs['pk']})

    def form_valid(self,form):
        messages.success(self.request,'予定日を更新しました')
        return super().form_valid(form)

    def form_invalid(self,form):
        messages.error(self.request,"予定日の更新に失敗しました")
        return super().form_invalid(form)

class CompanyDeleteView(LoginRequiredMixin,generic.DeleteView):
    model = Company
    template_name = 'company_delete.html'
    success_url = reverse_lazy('company:company_list')

    def delete(self,request,*args,**kwargs):
        messages.success(self.request,"日記を削除しました。")
        return super().delete(request,*args,**kwargs)
# Create your views here.
