
from .settings_common import *

DEBAG = True

EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

ALLOWED_HOSTS = []


MEDIA_ROOT = os.path.join(BASE_DIR,'media')

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,

    'loggers':{
        'django':{
            'handlers': ['console'],
            'level': 'INFO',
        },
        'company':{
            'handlers': ['console'],
            'level': 'DEBUG',
        },
    },

    'handlers':{
        'console':{
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
            'formatter': 'dev'
        },
    },

    'formatters': {
        'dev':{
            'format':'\t'.join([
                '%(asctime)s',
                '[%(levelname)s]',
                '%(pathname)s(Line:%(lineno)d)',
                '%(message)s'
            ])
        },
    }
}
