from django.contrib import admin

from .models import CustomUser
#from .models import BlogUser

admin.site.register(CustomUser)

#admin.site.register(BlogUser)

# Register your models here.
