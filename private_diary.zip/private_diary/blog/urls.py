from django.urls import path

from . import views

app_name = 'blog'
urlpatterns = [
    path('', views.IndexView.as_view(), name="home"),
    path('inquiry/', views.InquiryView.as_view(), name="inquiry"),
    path('blog-list/',views.BlogListView.as_view(),name="blog_list"),
    path('blog-create/',views.BlogCreateView.as_view(), name="blog_create"),

]