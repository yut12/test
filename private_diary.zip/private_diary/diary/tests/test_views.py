from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse_lazy

from ..models import Diary

class LoggedInTestCase(TestCase):
    #各テストクラスで共通の事前準備処理をオーバーライドした独自TestCase クラス
    def setUp(self):
        #テストメソッド実行前の前提設定
        self.password = '<ログインパスワード>'
        #各インスタンスメソッドで使うテスト用ユーザーを作成し
        #インスタンス変数に格納しておく
        self.test_user = get_user_model().objects.create_user(
            username='<ログインユーザー名>',
            email='<ログインユーザーのメールアドレス>',
            password=self.password)
        
        self.client.login(email=self.test_user.email,password=self.password)

class TestDiaryCreateView(LoggedInTestCase):
    #DiaryCreateView用のテストクラス
    def test_create_diary_success(self):
        #Postパラメータ
        params = {'title':'テストタイトル',
        'content':'本文',
        'photo1':'',
        'photo2':'',
        'photo3':''
        }
        #新規日記作成処理(post)を実行
        response = self.client.post(reverse_lazy('diary:diary_create'),params)
        #日記リストページへのリダイレクトを検証
        self.asserRedirects(response,reverse_lazy('diary:diary_list'))
        #日記データがDBに登録されているかを検証
        self.assertEqual(Diary.objects.filter(title='テストタイトル').count(),1)

    def test_create_diary_filure(self):
        
        #日記編集処理が成功することを検証する
        #テスト用日記データの作成
        diary = Diary.objects.create(user=self.test_user,title='タイトル編集前')
        
